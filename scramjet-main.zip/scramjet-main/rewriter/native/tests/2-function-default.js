function f(g = globalThis, l = location) {
  check(g);
  check(l);
}

f();
