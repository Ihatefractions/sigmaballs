const { location: x } = globalThis;

check(x);
